from typing import Iterable, Union, Type, Tuple

import torch

from cnsproject.network.connections import ConvolutionalConnection, PoolingConnection, T2FSMaxPoolingConnection
from cnsproject.network.neural_populations import NeuralPopulation


def get_convolution_2d_output_shape(
        input_shape,
        **kwargs
) -> Iterable[int]:
    # TODO
    pass


def get_pooling_2d_output_shape(
        input_shape,
        **kwargs
) -> Iterable[int]:
    # TODO
    pass


def convolution_2d_connection(
        input_population: NeuralPopulation,
        output_population_type: Type[NeuralPopulation],
        **kwarg  # Contains both parameters of output population and connection
) -> Tuple[NeuralPopulation, ConvolutionalConnection]:
    output_shape = get_convolution_2d_output_shape(input_population.shape, **kwarg)
    output_population = output_population_type(shape=output_shape, **kwarg)
    connection = ConvolutionalConnection(
        pre=input_population,
        post=output_population,
        **kwarg
    )
    return output_population, connection


def pooling_output_of(
        input_population: NeuralPopulation,
        output_population_type: Type[NeuralPopulation],
        pooling_type: Type[PoolingConnection] = T2FSMaxPoolingConnection,
        **kwarg  # Contains both parameters of output population and connection
) -> Tuple[NeuralPopulation, ConvolutionalConnection]:
    output_shape = get_pooling_2d_output_shape(input_population.shape, **kwarg)
    output_population = output_population_type(shape=output_shape, **kwarg)
    connection = pooling_type(
        pre=input_population,
        post=output_population,
        **kwarg
    )
    return output_population, connection
